const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Rutas de la API para productos
app.get('/api/productos', (req, res) => {
    const productosPath = path.join(__dirname, 'data/productos.json');
    
    fs.readFile(productosPath, 'utf8', (err, data) => {
        if (err) {
            // Si el archivo no existe, devolver productos por defecto
            const productosPorDefecto = [
                { id: 1, nombre: "Camisa Elegante", categoria: "Hombre", precio: 49.99, descripcion: "Camisa de algodón 100%", imagen: "images/producto1.jpg" },
                { id: 2, nombre: "Vestido de Noche", categoria: "Mujer", precio: 89.99, descripcion: "Vestido para ocasiones especiales", imagen: "images/producto2.jpg" }
            ];
            return res.json(productosPorDefecto);
        }
        
        res.json(JSON.parse(data));
    });
});

app.post('/api/productos', (req, res) => {
    const nuevoProducto = req.body;
    nuevoProducto.id = Date.now(); // ID simple basado en timestamp
    
    const productosPath = path.join(__dirname, 'data/productos.json');
    
    fs.readFile(productosPath, 'utf8', (err, data) => {
        let productos = [];
        
        if (!err && data) {
            productos = JSON.parse(data);
        }
        
        productos.push(nuevoProducto);
        
        fs.writeFile(productosPath, JSON.stringify(productos, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ error: 'Error al guardar el producto' });
            }
            
            res.json({ success: true, producto: nuevoProducto });
        });
    });
});

// Ruta para servir el panel de administración
app.get('/admin-panel.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/admin-panel.html'));
});

// Ruta para servir el login
app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/login.html'));
});

// Ruta principal
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
    console.log(`Panel de administración: http://localhost:${PORT}/login.html`);
});