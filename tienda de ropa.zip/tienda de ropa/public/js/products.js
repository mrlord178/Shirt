// PRODUCTS.JS - SISTEMA COMPLETO DE GESTIÓN DE PRODUCTOS

class ProductManager {
    constructor() {
        this.products = [];
        this.categories = ['Hombre', 'Mujer', 'Niños', 'Accesorios', 'Deportes', 'Unisex'];
        this.init();
    }
    
    init() {
        this.loadProducts();
        this.renderRecentProducts();
        this.renderProductsByCategory();
        this.bindEvents();
        console.log('✅ ProductManager inicializado con', this.products.length, 'productos');
    }
    
    // CARGAR PRODUCTOS DESDE localStorage
    loadProducts() {
        const savedProducts = localStorage.getItem('tiendaRopaProductos');
        
        if (savedProducts && savedProducts !== 'undefined') {
            try {
                this.products = JSON.parse(savedProducts);
                console.log('📦 Productos cargados desde localStorage:', this.products.length);
            } catch (error) {
                console.error('❌ Error al cargar productos:', error);
                this.products = this.getDefaultProducts();
            }
        } else {
            console.log('⚠️ No hay productos guardados, cargando productos por defecto');
            this.products = this.getDefaultProducts();
        }
        
        // Ordenar por ID (más reciente primero)
        this.products.sort((a, b) => b.id - a.id);
        
        // Guardar si no había nada
        if (!savedProducts || savedProducts === 'undefined') {
            this.saveProducts();
        }
    }
    
    // GUARDAR PRODUCTOS
    saveProducts() {
        try {
            localStorage.setItem('tiendaRopaProductos', JSON.stringify(this.products));
            console.log('💾 Productos guardados:', this.products.length);
        } catch (error) {
            console.error('❌ Error al guardar productos:', error);
        }
    }
    
    // PRODUCTOS POR DEFECTO (8 productos variados)
    getDefaultProducts() {
        return [
            {
                id: 1,
                nombre: "Camisa Casual Hombre Moderna",
                categoria: "Hombre",
                precio: 42.99,
                precioOriginal: 52.99,
                descripcion: "Camisa casual de algodón premium con corte moderno. Ideal para uso diario y ocasiones informales.",
                imagen: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300&h=300&fit=crop",
                stock: 18,
                destacado: true,
                fechaAgregado: new Date().toISOString().split('T')[0],
                tags: ["casual", "algodón", "moderno", "básico"],
                colores: ["Blanco", "Azul Claro", "Gris"],
                tallas: ["S", "M", "L", "XL"],
                vendidos: 45
            },
            {
                id: 2,
                nombre: "Pantalón Jeans Slim Fit",
                categoria: "Hombre",
                precio: 64.99,
                precioOriginal: 79.99,
                descripcion: "Jeans de alta calidad con corte slim fit. Elásticos y resistentes para máximo confort.",
                imagen: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=300&h=300&fit=crop",
                stock: 12,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["jeans", "slim fit", "elástico", "casual"],
                colores: ["Azul Oscuro", "Negro", "Gris"],
                tallas: ["28", "30", "32", "34", "36"],
                vendidos: 32
            },
            {
                id: 3,
                nombre: "Vestido Floral Verano Elegante",
                categoria: "Mujer",
                precio: 85.99,
                precioOriginal: 109.99,
                descripcion: "Vestido floral con diseño elegante perfecto para el verano. Tela ligera y fresca.",
                imagen: "https://images.unsplash.com/photo-1567095761054-7a02e69e5c43?w=300&h=300&fit=crop",
                stock: 9,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["verano", "floral", "elegante", "fiesta"],
                colores: ["Blanco con Flores", "Rosa Pastel", "Azul Cielo"],
                tallas: ["XS", "S", "M", "L"],
                vendidos: 28
            },
            {
                id: 4,
                nombre: "Blusa de Seda Premium",
                categoria: "Mujer",
                precio: 55.99,
                precioOriginal: 69.99,
                descripcion: "Blusa de seda natural 100% con detalles elegantes. Perfecta para oficina o eventos.",
                imagen: "https://images.unsplash.com/photo-1585487000160-6eb9ce6b5a74?w=300&h=300&fit=crop",
                stock: 15,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["seda", "elegante", "formal", "premium"],
                colores: ["Beige", "Negro", "Blanco Perla"],
                tallas: ["XS", "S", "M"],
                vendidos: 41
            },
            {
                id: 5,
                nombre: "Bolso Tote Cuero Genuino",
                categoria: "Accesorios",
                precio: 94.99,
                precioOriginal: 119.99,
                descripcion: "Bolso tote de cuero genuino italiano. Espacioso, elegante y funcional.",
                imagen: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=300&h=300&fit=crop",
                stock: 6,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["cuero", "accesorio", "elegante", "lujo"],
                colores: ["Marrón Café", "Negro", "Beige"],
                tallas: ["Único"],
                vendidos: 19
            },
            {
                id: 6,
                nombre: "Conjunto Deportivo Running Pro",
                categoria: "Deportes",
                precio: 49.99,
                precioOriginal: 64.99,
                descripcion: "Conjunto deportivo profesional para running. Tecnología dry-fit y máxima comodidad.",
                imagen: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=300&fit=crop",
                stock: 22,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["deporte", "running", "activo", "dry-fit"],
                colores: ["Negro", "Gris Grafito", "Azul Marino"],
                tallas: ["S", "M", "L", "XL"],
                vendidos: 56
            },
            {
                id: 7,
                nombre: "Conjunto Niño Aventurero",
                categoria: "Niños",
                precio: 32.99,
                precioOriginal: 44.99,
                descripcion: "Conjunto deportivo para niños resistente y cómodo. Diseños divertidos y coloridos.",
                imagen: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=300&h=300&fit=crop",
                stock: 17,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["niños", "deporte", "divertido", "cómodo"],
                colores: ["Rojo", "Azul", "Verde", "Amarillo"],
                tallas: ["4-6 años", "7-9 años", "10-12 años"],
                vendidos: 37
            },
            {
                id: 8,
                nombre: "Sudadera Oversize Unisex",
                categoria: "Unisex",
                precio: 38.99,
                precioOriginal: 49.99,
                descripcion: "Sudadera oversize unisex ultra cómoda. Tejido French Terry de alta calidad.",
                imagen: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=300&h=300&fit=crop",
                stock: 25,
                destacado: true,
                fechaAgregado: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                tags: ["unisex", "oversize", "casual", "cómodo"],
                colores: ["Gris Heather", "Negro", "Blanco Roto"],
                tallas: ["S", "M", "L", "XL", "XXL"],
                vendidos: 63
            }
        ];
    }
    
    // OBTENER ÚLTIMOS 6 PRODUCTOS
    getRecentProducts(limit = 6) {
        return this.products.slice(0, limit);
    }
    
    // OBTENER PRODUCTOS POR CATEGORÍA
    getProductsByCategory(categoria, limit = 3) {
        return this.products
            .filter(p => p.categoria.toLowerCase() === categoria.toLowerCase())
            .slice(0, limit);
    }
    
    // OBTENER TODAS LAS CATEGORÍAS CON PRODUCTOS
    getAllCategoriesWithProducts() {
        const categories = {};
        this.categories.forEach(cat => {
            categories[cat] = this.getProductsByCategory(cat, 3);
        });
        return categories;
    }
    
    // RENDERIZAR PRODUCTOS RECIENTES
    renderRecentProducts() {
        const container = document.getElementById('productos-recientes');
        if (!container) {
            console.log('⚠️ No se encontró #productos-recientes');
            return;
        }
        
        container.innerHTML = '';
        
        const recentProducts = this.getRecentProducts(6);
        
        if (recentProducts.length === 0) {
            container.innerHTML = this.getNoProductsHTML();
            console.log('ℹ️ No hay productos recientes para mostrar');
            return;
        }
        
        console.log('🔄 Renderizando', recentProducts.length, 'productos recientes');
        
        recentProducts.forEach(producto => {
            const card = this.createProductCard(producto);
            container.appendChild(card);
        });
        
        // Inicializar animaciones después de renderizar
        setTimeout(() => this.initProductAnimations(), 100);
    }
    
    // RENDERIZAR PRODUCTOS POR CATEGORÍA
    renderProductsByCategory() {
        const categories = [
            { id: 'hombre', name: 'Hombre' },
            { id: 'mujer', name: 'Mujer' },
            { id: 'accesorios', name: 'Accesorios' },
            { id: 'deportes', name: 'Deportes' },
            { id: 'ninos', name: 'Niños' },
            { id: 'unisex', name: 'Unisex' }
        ];
        
        categories.forEach(cat => {
            const containerId = `categoria-${cat.id}`;
            const container = document.getElementById(containerId);
            
            if (!container) {
                console.log(`⚠️ No se encontró #${containerId}`);
                return;
            }
            
            container.innerHTML = '';
            
            const categoryProducts = this.getProductsByCategory(cat.name, 3);
            
            if (categoryProducts.length === 0) {
                container.innerHTML = `
                    <div class="no-category-products">
                        <i class="fas fa-box-open"></i>
                        <p>Próximamente más productos en ${cat.name}</p>
                    </div>
                `;
                return;
            }
            
            console.log(`🔄 Renderizando ${categoryProducts.length} productos para categoría ${cat.name}`);
            
            categoryProducts.forEach(producto => {
                const card = this.createProductCard(producto, true); // true = modo simplificado
                container.appendChild(card);
            });
        });
    }
    
    // CREAR TARJETA DE PRODUCTO
    createProductCard(producto, simplified = false) {
        const card = document.createElement('div');
        card.className = `producto-card ${simplified ? 'simplified' : ''}`;
        card.dataset.id = producto.id;
        card.dataset.category = producto.categoria.toLowerCase();
        
        const tieneDescuento = producto.precioOriginal && producto.precioOriginal > producto.precio;
        const porcentajeDescuento = tieneDescuento ? 
            Math.round((1 - producto.precio / producto.precioOriginal) * 100) : 0;
        
        const esNuevo = this.isProductNew(producto.fechaAgregado);
        const stockBajo = producto.stock < 5;
        
        card.innerHTML = `
            ${tieneDescuento ? `
                <div class="descuento-badge">-${porcentajeDescuento}%</div>
            ` : ''}
            
            ${esNuevo ? `
                <div class="nuevo-badge">NUEVO</div>
            ` : ''}
            
            <div class="producto-img img-zoom-container">
                <img src="${producto.imagen}" alt="${producto.nombre}" 
                     class="img-zoom" 
                     loading="lazy"
                     onerror="this.onerror=null; this.src='https://via.placeholder.com/300x300/2c3e50/ecf0f1?text=${encodeURIComponent(producto.nombre.substring(0, 20))}'">
                ${stockBajo ? `
                    <div class="low-stock-badge">
                        <i class="fas fa-exclamation-circle"></i> Solo ${producto.stock} disponibles
                    </div>
                ` : ''}
                ${producto.vendidos > 50 ? `
                    <div class="popular-badge">
                        <i class="fas fa-fire"></i> Popular
                    </div>
                ` : ''}
            </div>
            
            <div class="producto-info">
                <div class="producto-categoria">
                    <i class="fas fa-tag"></i> ${producto.categoria}
                    ${!simplified ? `
                        <span class="producto-fecha">
                            <i class="far fa-calendar"></i> ${this.formatDate(producto.fechaAgregado)}
                        </span>
                    ` : ''}
                </div>
                
                <h3 class="producto-nombre">${producto.nombre}</h3>
                
                <div class="producto-precio">
                    ${tieneDescuento ? `
                        <span class="precio-original">$${producto.precioOriginal.toFixed(2)}</span>
                    ` : ''}
                    <span class="precio-actual">$${producto.precio.toFixed(2)}</span>
                    ${!simplified && producto.vendidos > 0 ? `
                        <span class="vendidos-badge">
                            <i class="fas fa-shopping-cart"></i> ${producto.vendidos} vendidos
                        </span>
                    ` : ''}
                </div>
                
                ${!simplified ? `
                    <p class="producto-descripcion">${producto.descripcion}</p>
                ` : ''}
                
                <div class="producto-meta">
                    <div class="producto-stock ${stockBajo ? 'stock-bajo' : ''}">
                        <i class="fas fa-box"></i> 
                        <span class="stock-text">${producto.stock} disponibles</span>
                    </div>
                    
                    ${!simplified ? `
                        <div class="producto-colores">
                            ${producto.colores.map(color => `
                                <span class="color-dot" style="background-color: ${this.getColorCode(color)}" title="${color}"></span>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
                
                <div class="producto-actions">
                    <button class="btn-primary btn-add-to-cart btn-magnetic" 
                            data-id="${producto.id}"
                            onclick="agregarAlCarrito(${producto.id})">
                        <i class="fas fa-cart-plus"></i> Agregar
                    </button>
                    
                    ${!simplified ? `
                        <button class="btn-secondary btn-view-details" 
                                data-id="${producto.id}"
                                onclick="verDetallesProducto(${producto.id})">
                            <i class="fas fa-eye"></i> Ver
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
        
        return card;
    }
    
    // VERIFICAR SI EL PRODUCTO ES NUEVO (últimos 7 días)
    isProductNew(dateString) {
        if (!dateString) return false;
        
        const productDate = new Date(dateString);
        const currentDate = new Date();
        const differenceInDays = Math.floor((currentDate - productDate) / (1000 * 60 * 60 * 24));
        
        return differenceInDays <= 7;
    }
    
    // FORMATEAR FECHA
    formatDate(dateString) {
        if (!dateString) return 'Reciente';
        
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) return 'Hoy';
        if (diffDays === 1) return 'Ayer';
        if (diffDays < 7) return `Hace ${diffDays} días`;
        
        return date.toLocaleDateString('es-ES', {
            day: 'numeric',
            month: 'short'
        });
    }
    
    // OBTENER CÓDIGO DE COLOR
    getColorCode(color) {
        const colores = {
            'Blanco': '#ffffff', 'Negro': '#000000', 
            'Azul': '#3498db', 'Azul Claro': '#5dade2', 'Azul Oscuro': '#2c3e50', 'Azul Cielo': '#85c1e9', 'Azul Marino': '#1b4f72',
            'Rojo': '#e74c3c', 'Rosa': '#ff9ff3', 'Rosa Pastel': '#fadbd8',
            'Gris': '#95a5a6', 'Gris Grafito': '#626567', 'Gris Heather': '#909497',
            'Marrón': '#8b4513', 'Marrón Café': '#7d6608',
            'Beige': '#f5deb3', 'Blanco Perla': '#fdfefe', 'Blanco Roto': '#f2f3f4',
            'Verde': '#2ecc71', 'Amarillo': '#f1c40f'
        };
        
        return colores[color] || '#7f8c8d';
    }
    
    // ANIMACIONES PARA PRODUCTOS
    initProductAnimations() {
        const productCards = document.querySelectorAll('.producto-card');
        
        productCards.forEach((card, index) => {
            // Retraso escalonado para animación
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('animate-fade-in-up');
            
            // Efecto hover mejorado
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px)';
                this.style.boxShadow = '0 20px 40px rgba(0,0,0,0.15)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'var(--shadow)';
            });
        });
    }
    
    // HTML CUANDO NO HAY PRODUCTOS
    getNoProductsHTML() {
        return `
            <div class="no-products">
                <div class="no-products-icon">
                    <i class="fas fa-box-open"></i>
                </div>
                <h3>No hay productos recientes</h3>
                <p>Agrega productos desde el panel de administración</p>
                <a href="login.html" class="btn-primary">
                    <i class="fas fa-user-cog"></i> Ir al Panel Admin
                </a>
            </div>
        `;
    }
    
    // BINDEAR EVENTOS
    bindEvents() {
        // Recargar productos cuando se agreguen nuevos
        document.addEventListener('productAdded', () => {
            console.log('🔄 Evento productAdded recibido, recargando productos...');
            this.loadProducts();
            this.renderRecentProducts();
            this.renderProductsByCategory();
        });
        
        // Recargar productos cuando se actualicen
        document.addEventListener('productUpdated', () => {
            console.log('🔄 Evento productUpdated recibido, recargando productos...');
            this.loadProducts();
            this.renderRecentProducts();
            this.renderProductsByCategory();
        });
        
        // Escuchar clicks en botones de categoría
        document.addEventListener('click', (e) => {
            if (e.target.closest('.categoria-header a')) {
                e.preventDefault();
                const category = e.target.closest('.categoria-header a').getAttribute('href').replace('#categoria-', '');
                this.showAllCategoryProducts(category);
            }
        });
        
        // Inicializar tooltips para colores
        setTimeout(() => {
            this.initColorTooltips();
        }, 500);
    }
    
    // INICIALIZAR TOOLTIPS PARA COLORES
    initColorTooltips() {
        const colorDots = document.querySelectorAll('.color-dot');
        colorDots.forEach(dot => {
            dot.addEventListener('mouseenter', function() {
                const colorName = this.getAttribute('title');
                const tooltip = document.createElement('div');
                tooltip.className = 'color-tooltip';
                tooltip.textContent = colorName;
                tooltip.style.cssText = `
                    position: absolute;
                    background: #333;
                    color: white;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 0.8rem;
                    white-space: nowrap;
                    z-index: 1000;
                    transform: translate(-50%, -30px);
                `;
                this.appendChild(tooltip);
            });
            
            dot.addEventListener('mouseleave', function() {
                const tooltip = this.querySelector('.color-tooltip');
                if (tooltip) tooltip.remove();
            });
        });
    }
    
    // MOSTRAR TODOS LOS PRODUCTOS DE UNA CATEGORÍA
    showAllCategoryProducts(categoryName) {
        const category = this.categories.find(c => c.toLowerCase() === categoryName.toLowerCase());
        if (!category) return;
        
        const products = this.products.filter(p => p.categoria === category);
        
        // Crear modal con todos los productos de la categoría
        const modalHTML = `
            <div class="modal-overlay active" id="categoryModal">
                <div class="modal" style="max-width: 1200px;">
                    <div class="modal-header">
                        <h3><i class="fas fa-tag"></i> Todos los productos de ${category}</h3>
                        <button class="close-modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="category-products-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; padding: 20px 0;">
                            ${products.length > 0 ? 
                                products.map(p => `
                                    <div class="producto-card simplified">
                                        <div class="producto-img">
                                            <img src="${p.imagen}" alt="${p.nombre}" style="width: 100%; height: 200px; object-fit: cover;">
                                        </div>
                                        <div class="producto-info">
                                            <h4>${p.nombre}</h4>
                                            <div style="color: var(--secondary-color); font-weight: bold; margin: 10px 0;">
                                                $${p.precio.toFixed(2)}
                                            </div>
                                            <button class="btn-primary" onclick="agregarAlCarrito(${p.id});" style="width: 100%;">
                                                <i class="fas fa-cart-plus"></i> Agregar
                                            </button>
                                        </div>
                                    </div>
                                `).join('') :
                                `<div style="text-align: center; padding: 40px; color: var(--gray-color);">
                                    <i class="fas fa-box-open" style="font-size: 3rem;"></i>
                                    <p>No hay productos en esta categoría</p>
                                </div>`
                            }
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Configurar cierre del modal
        const modal = document.getElementById('categoryModal');
        modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
        modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
            if (e.target === modal.querySelector('.modal-overlay')) modal.remove();
        });
    }
    
    // AGREGAR NUEVO PRODUCTO (desde panel admin)
    addProduct(productData) {
        console.log('➕ Agregando nuevo producto:', productData.nombre);
        
        const nuevoId = this.products.length > 0 ? 
            Math.max(...this.products.map(p => p.id)) + 1 : 1;
        
        const nuevoProducto = {
            id: nuevoId,
            nombre: productData.nombre || 'Nuevo Producto',
            categoria: productData.categoria || 'Hombre',
            precio: parseFloat(productData.precio) || 0,
            precioOriginal: parseFloat(productData.precioOriginal) || parseFloat(productData.precio) || 0,
            descripcion: productData.descripcion || 'Descripción del producto',
            imagen: productData.imagen || this.getDefaultImageForCategory(productData.categoria),
            stock: parseInt(productData.stock) || 0,
            destacado: Boolean(productData.destacado),
            fechaAgregado: new Date().toISOString().split('T')[0],
            tags: productData.tags ? productData.tags.split(',').map(t => t.trim()) : [],
            colores: productData.colores ? productData.colores.split(',').map(c => c.trim()) : ['Negro'],
            tallas: productData.tallas ? productData.tallas.split(',').map(t => t.trim()) : ['Único'],
            vendidos: 0
        };
        
        // Agregar al inicio del array
        this.products.unshift(nuevoProducto);
        this.saveProducts();
        
        console.log('✅ Producto agregado:', nuevoProducto);
        
        // Disparar evento
        const event = new CustomEvent('productAdded', { detail: nuevoProducto });
        document.dispatchEvent(event);
        
        return nuevoProducto;
    }
    
    // OBTENER IMAGEN POR DEFECTO POR CATEGORÍA
    getDefaultImageForCategory(categoria) {
        const defaultImages = {
            'Hombre': 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=300&h=300&fit=crop',
            'Mujer': 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=300&h=300&fit=crop',
            'Niños': 'https://images.unsplash.com/photo-1519241047957-2d37ef4a2f39?w=300&h=300&fit=crop',
            'Accesorios': 'https://images.unsplash.com/photo-1590649887896-6c8e6668407f?w=300&h=300&fit=crop',
            'Deportes': 'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=300&h=300&fit=crop',
            'Unisex': 'https://images.unsplash.com/photo-1520006403909-838d6b92c22e?w=300&h=300&fit=crop'
        };
        
        return defaultImages[categoria] || 'https://via.placeholder.com/300x300/2c3e50/ecf0f1?text=Producto';
    }
    
    // ACTUALIZAR PRODUCTO
    updateProduct(id, productData) {
        const index = this.products.findIndex(p => p.id === id);
        
        if (index !== -1) {
            this.products[index] = {
                ...this.products[index],
                ...productData,
                precio: parseFloat(productData.precio) || this.products[index].precio,
                precioOriginal: parseFloat(productData.precioOriginal) || this.products[index].precioOriginal,
                stock: parseInt(productData.stock) || this.products[index].stock,
                destacado: productData.destacado !== undefined ? Boolean(productData.destacado) : this.products[index].destacado
            };
            
            this.saveProducts();
            
            // Disparar evento
            const event = new CustomEvent('productUpdated', { detail: this.products[index] });
            document.dispatchEvent(event);
            
            return true;
        }
        
        return false;
    }
    
    // ELIMINAR PRODUCTO
    deleteProduct(id) {
        const index = this.products.findIndex(p => p.id === id);
        
        if (index !== -1) {
            const deleted = this.products.splice(index, 1);
            this.saveProducts();
            console.log('🗑️ Producto eliminado:', deleted[0].nombre);
            return true;
        }
        
        return false;
    }
    
    // OBTENER PRODUCTO POR ID
    getProductById(id) {
        return this.products.find(p => p.id === parseInt(id));
    }
    
    // BUSCAR PRODUCTOS
    searchProducts(query) {
        const searchLower = query.toLowerCase();
        return this.products.filter(p => 
            p.nombre.toLowerCase().includes(searchLower) ||
            p.descripcion.toLowerCase().includes(searchLower) ||
            p.tags.some(tag => tag.toLowerCase().includes(searchLower)) ||
            p.categoria.toLowerCase().includes(searchLower)
        );
    }
    
    // OBTENER ESTADÍSTICAS
    getStats() {
        return {
            totalProducts: this.products.length,
            totalStock: this.products.reduce((sum, p) => sum + p.stock, 0),
            totalValue: this.products.reduce((sum, p) => sum + (p.precio * p.stock), 0),
            categories: this.categories.map(cat => ({
                name: cat,
                count: this.products.filter(p => p.categoria === cat).length
            }))
        };
    }
}

// INICIALIZAR GESTOR DE PRODUCTOS GLOBAL
let productManager;

// FUNCIÓN DE INICIALIZACIÓN
function initProductSystem() {
    productManager = new ProductManager();
    
    // Función global para agregar al carrito
    window.agregarAlCarrito = function(productoId) {
        const producto = productManager.getProductById(productoId);
        
        if (producto) {
            // Verificar stock
            if (producto.stock <= 0) {
                showNotification('Producto agotado', 'error');
                return;
            }
            
            console.log('🛒 Agregando al carrito:', producto.nombre);
            
            // Disparar evento personalizado
            const event = new CustomEvent('addToCart', {
                detail: producto
            });
            document.dispatchEvent(event);
            
            // Mostrar notificación
            showNotification(`${producto.nombre} agregado al carrito`, 'success');
        } else {
            console.error('❌ Producto no encontrado:', productoId);
            showNotification('Producto no disponible', 'error');
        }
    };
    
    // Función global para ver detalles
    window.verDetallesProducto = function(productoId) {
        const producto = productManager.getProductById(productoId);
        
        if (producto) {
            // Crear modal de detalles
            const modalHTML = `
                <div class="modal-overlay active" id="productDetailsModal">
                    <div class="modal" style="max-width: 900px;">
                        <div class="modal-header">
                            <h3>Detalles del Producto</h3>
                            <button class="close-modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 40px;">
                                <div>
                                    <img src="${producto.imagen}" alt="${producto.nombre}" 
                                         style="width: 100%; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);"
                                         onerror="this.src='https://via.placeholder.com/400x400/2c3e50/ecf0f1?text=${encodeURIComponent(producto.nombre.substring(0, 20))}'">
                                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                                        ${producto.tags.map(tag => `
                                            <span style="background: #f0f0f0; padding: 5px 12px; border-radius: 20px; font-size: 0.85rem;">
                                                #${tag}
                                            </span>
                                        `).join('')}
                                    </div>
                                </div>
                                <div>
                                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                                        <span style="background: var(--primary-color); color: white; padding: 5px 15px; border-radius: 20px; font-size: 0.9rem;">
                                            ${producto.categoria}
                                        </span>
                                        ${productManager.isProductNew(producto.fechaAgregado) ? 
                                            '<span style="background: #3498db; color: white; padding: 5px 15px; border-radius: 20px; font-size: 0.9rem;">NUEVO</span>' : ''}
                                        ${producto.vendidos > 50 ? 
                                            '<span style="background: #e74c3c; color: white; padding: 5px 15px; border-radius: 20px; font-size: 0.9rem;"><i class="fas fa-fire"></i> POPULAR</span>' : ''}
                                    </div>
                                    
                                    <h2 style="margin: 0 0 15px 0;">${producto.nombre}</h2>
                                    
                                    <div style="font-size: 2.5rem; font-weight: 700; color: var(--secondary-color); margin: 20px 0;">
                                        $${producto.precio.toFixed(2)}
                                        ${producto.precioOriginal && producto.precioOriginal > producto.precio ? 
                                            `<div style="font-size: 1.2rem; text-decoration: line-through; color: var(--gray-color); margin-top: 5px;">
                                                $${producto.precioOriginal.toFixed(2)}
                                            </div>` : ''
                                        }
                                    </div>
                                    
                                    <p style="line-height: 1.8; color: #555; margin: 20px 0;">${producto.descripcion}</p>
                                    
                                    <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 25px 0;">
                                        <h4 style="margin-top: 0;">Disponibilidad</h4>
                                        <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                                            <div>
                                                <i class="fas fa-box" style="color: var(--primary-color);"></i>
                                                <strong style="margin-left: 8px;">Stock:</strong>
                                                <span style="margin-left: 5px; color: ${producto.stock < 5 ? '#e74c3c' : '#2ecc71'};">
                                                    ${producto.stock} unidades
                                                </span>
                                            </div>
                                            <div>
                                                <i class="fas fa-shopping-cart" style="color: var(--primary-color);"></i>
                                                <strong style="margin-left: 8px;">Vendidos:</strong>
                                                <span style="margin-left: 5px;">${producto.vendidos}</span>
                                            </div>
                                        </div>
                                        
                                        <h4>Colores disponibles</h4>
                                        <div style="display: flex; gap: 15px; margin-top: 10px; margin-bottom: 20px;">
                                            ${producto.colores.map(color => `
                                                <div style="text-align: center;">
                                                    <div style="width: 40px; height: 40px; border-radius: 50%; background: ${productManager.getColorCode(color)}; 
                                                         border: 3px solid #fff; box-shadow: 0 3px 10px rgba(0,0,0,0.1); margin: 0 auto;"></div>
                                                    <small style="display: block; margin-top: 5px;">${color}</small>
                                                </div>
                                            `).join('')}
                                        </div>
                                        
                                        <h4>Tallas disponibles</h4>
                                        <div style="display: flex; gap: 10px; margin-top: 10px;">
                                            ${producto.tallas.map(talla => `
                                                <div style="padding: 10px 20px; border: 2px solid #ddd; border-radius: 8px; 
                                                     cursor: pointer; transition: all 0.3s; text-align: center; min-width: 50px;"
                                                     onmouseover="this.style.borderColor='var(--primary-color)'; this.style.backgroundColor='#f0f7ff'"
                                                     onmouseout="this.style.borderColor='#ddd'; this.style.backgroundColor='transparent'">
                                                    ${talla}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                    
                                    <button class="btn-primary" style="width: 100%; padding: 18px; font-size: 1.1rem; margin-top: 10px;" 
                                            onclick="agregarAlCarrito(${producto.id}); closeProductDetails();">
                                        <i class="fas fa-cart-plus"></i> Agregar al Carrito - $${producto.precio.toFixed(2)}
                                    </button>
                                    
                                    <button class="btn-secondary" style="width: 100%; padding: 18px; font-size: 1.1rem; margin-top: 10px;" 
                                            onclick="closeProductDetails()">
                                        <i class="fas fa-times"></i> Cerrar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Configurar cierre
            window.closeProductDetails = function() {
                const modal = document.getElementById('productDetailsModal');
                if (modal) modal.remove();
            };
            
            const modal = document.getElementById('productDetailsModal');
            modal.querySelector('.close-modal').addEventListener('click', window.closeProductDetails);
            modal.querySelector('.modal-overlay').addEventListener('click', function(e) {
                if (e.target === this) window.closeProductDetails();
            });
        }
    };
    
    // Mostrar estadísticas en consola
    console.log('📊 Estadísticas:', productManager.getStats());
}

// FUNCIÓN PARA MOSTRAR NOTIFICACIONES
function showNotification(message, type = 'success') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${type === 'success' ? '#2ecc71' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        border-radius: 10px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        z-index: 10000;
        transform: translateX(120%);
        transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
    `;
    
    const icon = type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle';
    
    notification.innerHTML = `
        <i class="fas ${icon}" style="font-size: 1.2rem;"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Mostrar con animación
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Ocultar después de 3 segundos
    setTimeout(() => {
        notification.style.transform = 'translateX(120%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 500);
    }, 3000);
}

// INICIALIZAR CUANDO EL DOM ESTÉ LISTO
document.addEventListener('DOMContentLoaded', function() {
    // Esperar un poco para asegurar que todo esté cargado
    setTimeout(() => {
        initProductSystem();
        console.log('🚀 Sistema de productos inicializado');
    }, 500);
});

// EXPORTAR PARA USO EN OTROS ARCHIVOS
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ProductManager, initProductSystem };
}