// DOM completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Menu hamburguesa para móviles
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Cerrar menú al hacer clic en un enlace
        document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        }));
    }
    
    // Desplazamiento suave para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#') return;
            
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Cargar productos desde localStorage o API simulada
    cargarProductos();
    
    // Efecto de scroll en header
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        }
    });
    
    // Inicializar año actual en footer
    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});

// Función para cargar productos
function cargarProductos() {
    const productosContainer = document.getElementById('productos-container');
    
    if (!productosContainer) return;
    
    // Intentar cargar productos desde localStorage
    let productos = obtenerProductosDesdeLocalStorage();
    
    // Si no hay productos en localStorage, cargar algunos por defecto
    if (productos.length === 0) {
        productos = obtenerProductosPorDefecto();
        guardarProductosEnLocalStorage(productos);
    }
    
    // Renderizar productos en la página
    renderizarProductos(productos);
}

// Obtener productos desde localStorage
function obtenerProductosDesdeLocalStorage() {
    try {
        const productosGuardados = localStorage.getItem('productosTiendaRopa');
        return productosGuardados ? JSON.parse(productosGuardados) : [];
    } catch (error) {
        console.error('Error al cargar productos:', error);
        return [];
    }
}

// Guardar productos en localStorage
function guardarProductosEnLocalStorage(productos) {
    try {
        localStorage.setItem('productosTiendaRopa', JSON.stringify(productos));
    } catch (error) {
        console.error('Error al guardar productos:', error);
    }
}

// Productos por defecto para mostrar inicialmente
function obtenerProductosPorDefecto() {
    return [
        {
            id: 1,
            nombre: "Camisa Elegante Hombre",
            categoria: "Hombre",
            precio: 49.99,
            descripcion: "Camisa de algodón 100% con corte moderno y elegante.",
            imagen: "images/producto1.jpg"
        },
        {
            id: 2,
            nombre: "Vestido de Noche",
            categoria: "Mujer",
            precio: 89.99,
            descripcion: "Vestido largo para ocasiones especiales.",
            imagen: "images/producto2.jpg"
        },
        {
            id: 3,
            nombre: "Sudadera con Capucha",
            categoria: "Unisex",
            precio: 39.99,
            descripcion: "Cómoda sudadera para uso diario.",
            imagen: "images/producto3.jpg"
        },
        {
            id: 4,
            nombre: "Zapatos Formales",
            categoria: "Hombre",
            precio: 79.99,
            descripcion: "Zapatos de cuero para ocasiones formales.",
            imagen: "images/producto4.jpg"
        },
        {
            id: 5,
            nombre: "Bolso de Cuero",
            categoria: "Accesorios",
            precio: 59.99,
            descripcion: "Bolso elegante hecho con cuero genuino.",
            imagen: "images/producto5.jpg"
        },
        {
            id: 6,
            nombre: "Conjunto Deportivo",
            categoria: "Deportes",
            precio: 44.99,
            descripcion: "Conjunto cómodo para actividades deportivas.",
            imagen: "images/producto6.jpg"
        }
    ];
}

// Renderizar productos en el grid
function renderizarProductos(productos) {
    const productosContainer = document.getElementById('productos-container');
    
    if (!productosContainer) return;
    
    // Limpiar contenedor
    productosContainer.innerHTML = '';
    
    // Crear tarjetas de producto
    productos.forEach(producto => {
        const productoCard = document.createElement('div');
        productoCard.className = 'producto-card';
        
        productoCard.innerHTML = `
            <div class="producto-img">
                <img src="${producto.imagen}" alt="${producto.nombre}" onerror="this.src='images/placeholder.jpg'">
            </div>
            <div class="producto-info">
                <div class="producto-categoria">${producto.categoria}</div>
                <h3 class="producto-nombre">${producto.nombre}</h3>
                <div class="producto-precio">$${producto.precio.toFixed(2)}</div>
                <p class="producto-descripcion">${producto.descripcion}</p>
                <button class="btn-primary" onclick="agregarAlCarrito(${producto.id})">Agregar al Carrito</button>
            </div>
        `;
        
        productosContainer.appendChild(productoCard);
    });
}

// Función simulada para agregar al carrito
function agregarAlCarrito(productoId) {
    // En una implementación real, esto se conectaría con un sistema de carrito
    alert(`Producto ${productoId} agregado al carrito (función de demostración)`);
}
document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const btnCategorias = document.getElementById('btnCategorias');
    const menuCategorias = document.getElementById('menuCategorias');
    const opcionesCategoria = document.querySelectorAll('.opcion-categoria');
    
    // Crear overlay si no existe
    let overlay = document.querySelector('.overlay-menu');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'overlay-menu';
        document.body.appendChild(overlay);
    }
    
    // Variables de estado
    let menuAbierto = false;
    
    // Función para abrir el menú
    function abrirMenu() {
        menuCategorias.classList.add('mostrar');
        overlay.classList.add('mostrar');
        menuAbierto = true;
        
        // Animar la flecha del botón
        const icono = btnCategorias.querySelector('i');
        if (icono) {
            icono.style.transform = 'rotate(180deg)';
        }
    }
    
    // Función para cerrar el menú
    function cerrarMenu() {
        menuCategorias.classList.remove('mostrar');
        overlay.classList.remove('mostrar');
        menuAbierto = false;
        
        // Restaurar la flecha del botón
        const icono = btnCategorias.querySelector('i');
        if (icono) {
            icono.style.transform = 'rotate(0deg)';
        }
    }
    
    // Función para alternar el menú
    function toggleMenu() {
        if (menuAbierto) {
            cerrarMenu();
        } else {
            abrirMenu();
        }
    }
    
    // Evento para abrir/cerrar menú
    btnCategorias.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleMenu();
    });
    
    // Evento para seleccionar una opción
    opcionesCategoria.forEach(opcion => {
        opcion.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Obtener el ID de la sección destino
            const targetId = this.getAttribute('data-target');
            const destino = this.getAttribute('href');
            
            // Cerrar el menú
            cerrarMenu();
            
            // Desplazarse a la sección después de un pequeño delay
            setTimeout(() => {
                // Si es un enlace interno (#)
                if (destino.startsWith('#')) {
                    const seccion = document.querySelector(destino);
                    if (seccion) {
                        // Desplazamiento suave
                        seccion.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        
                        // Resaltar la sección
                        resaltarSeccion(seccion);
                    }
                }
            }, 300);
        });
    });
    
    // Función para resaltar la sección seleccionada
    function resaltarSeccion(seccion) {
        // Guardar el estilo original
        const estiloOriginal = seccion.style.boxShadow;
        
        // Aplicar resaltado
        seccion.style.boxShadow = '0 0 0 4px rgba(0, 123, 255, 0.3)';
        seccion.style.transition = 'box-shadow 0.3s ease';
        
        // Remover el resaltado después de 2 segundos
        setTimeout(() => {
            seccion.style.boxShadow = estiloOriginal;
        }, 2000);
    }
    
    // Cerrar menú al hacer clic fuera
    document.addEventListener('click', function(e) {
        if (menuAbierto && 
            !menuCategorias.contains(e.target) && 
            !btnCategorias.contains(e.target)) {
            cerrarMenu();
        }
    });
    
    // Cerrar menú con tecla ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && menuAbierto) {
            cerrarMenu();
        }
    });
    
    // Cerrar menú al hacer scroll (opcional)
    window.addEventListener('scroll', function() {
        if (menuAbierto) {
            cerrarMenu();
        }
    });
});



