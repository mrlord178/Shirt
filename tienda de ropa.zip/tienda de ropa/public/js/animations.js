// ANIMACIONES INTERACTIVAS PARA LA TIENDA DE ROPA

document.addEventListener('DOMContentLoaded', function() {
    
    // 1. ANIMACIÓN DE ENTRADA PARA ELEMENTOS
    function initScrollAnimations() {
        const revealElements = document.querySelectorAll('.reveal');
        
        const revealOnScroll = () => {
            const windowHeight = window.innerHeight;
            const revealPoint = 150;
            
            revealElements.forEach(element => {
                const revealTop = element.getBoundingClientRect().top;
                
                if (revealTop < windowHeight - revealPoint) {
                    element.classList.add('active');
                }
            });
        };
        
        window.addEventListener('scroll', revealOnScroll);
        revealOnScroll(); // Ejecutar al cargar
    }
    
    // 2. EFECTO DE AGREGAR AL CARRITO CON ANIMACIÓN
    function initAddToCartAnimations() {
        const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');
        const cartAnimation = document.getElementById('cartAnimation');
        const cartFloatBtn = document.getElementById('cartFloatBtn');
        const cartCount = document.getElementById('cartCount');
        
        if (!addToCartButtons.length || !cartAnimation || !cartFloatBtn) return;
        
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const buttonRect = this.getBoundingClientRect();
                const cartRect = cartFloatBtn.getBoundingClientRect();
                
                // Calcular posición inicial y final
                const startX = buttonRect.left + buttonRect.width / 2;
                const startY = buttonRect.top + buttonRect.height / 2;
                const endX = cartRect.left + cartRect.width / 2;
                const endY = cartRect.top + cartRect.height / 2;
                
                // Configurar animación
                cartAnimation.style.setProperty('--end-x', `${endX - startX}px`);
                cartAnimation.style.setProperty('--end-y', `${endY - startY}px`);
                
                cartAnimation.style.left = `${startX}px`;
                cartAnimation.style.top = `${startY}px`;
                cartAnimation.style.opacity = '1';
                
                // Iniciar animación
                cartAnimation.style.animation = 'flyToCart 0.8s cubic-bezier(0.65, 0, 0.35, 1) forwards';
                
                // Actualizar contador del carrito
                updateCartCount();
                
                // Mostrar notificación
                showNotification('Producto agregado al carrito', 'success');
                
                // Efecto de vibración en el botón del carrito
                cartFloatBtn.style.animation = 'shake 0.5s ease';
                setTimeout(() => {
                    cartFloatBtn.style.animation = 'float 3s ease-in-out infinite';
                }, 500);
                
                // Reiniciar animación después de completarse
                setTimeout(() => {
                    cartAnimation.style.animation = '';
                    cartAnimation.style.opacity = '0';
                }, 800);
            });
        });
    }
    
    // 3. NOTIFICACIONES FLOTANTES
    function showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        if (!notification) return;
        
        // Crear notificación si no existe
        if (!notification) {
            const newNotification = document.createElement('div');
            newNotification.id = 'notification';
            newNotification.className = 'notification';
            document.body.appendChild(newNotification);
        }
        
        // Configurar mensaje y tipo
        notification.textContent = message;
        notification.className = 'notification';
        
        // Icono según tipo
        let icon = 'fa-check-circle';
        if (type === 'error') icon = 'fa-exclamation-circle';
        if (type === 'info') icon = 'fa-info-circle';
        
        notification.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
        notification.classList.add(type, 'show');
        
        // Ocultar después de 3 segundos
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    // 4. EFECTO DE CONTADOR DEL CARRITO
    function updateCartCount() {
        const cartCount = document.getElementById('cartCount');
        if (!cartCount) return;
        
        // Incrementar contador
        let currentCount = parseInt(cartCount.textContent) || 0;
        currentCount++;
        
        // Efecto de incremento
        cartCount.textContent = currentCount;
        cartCount.style.transform = 'scale(1.5)';
        
        setTimeout(() => {
            cartCount.style.transform = 'scale(1)';
        }, 300);
        
        // Guardar en localStorage
        localStorage.setItem('cartCount', currentCount);
    }
    
    // 5. EFECTO HOVER PARA TARJETAS DE PRODUCTO
    function initProductCardHoverEffects() {
        const productCards = document.querySelectorAll('.producto-card');
        
        productCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.zIndex = '10';
                
                // Agregar efecto de brillo
                const shine = document.createElement('div');
                shine.className = 'card-shine';
                shine.style.cssText = `
                    position: absolute;
                    top: 0;
                    left: -100%;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                    transition: left 0.6s;
                `;
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(shine);
                
                setTimeout(() => {
                    shine.style.left = '100%';
                }, 10);
                
                // Eliminar elemento después de la animación
                setTimeout(() => {
                    if (shine.parentNode) {
                        shine.parentNode.removeChild(shine);
                    }
                }, 700);
            });
        });
    }
    
    // 6. EFECTO PARA BOTONES ESPECIALES
    function initSpecialButtons() {
        // Botones con efecto de onda al hacer clic
        const specialButtons = document.querySelectorAll('.btn-primary, .btn-secondary');
        
        specialButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                // Crear efecto de onda
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.7);
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                // Eliminar elemento después de la animación
                setTimeout(() => {
                    if (ripple.parentNode) {
                        ripple.parentNode.removeChild(ripple);
                    }
                }, 600);
            });
        });
        
        // Agregar keyframes para ripple dinámicamente
        if (!document.querySelector('#ripple-styles')) {
            const style = document.createElement('style');
            style.id = 'ripple-styles';
            style.textContent = `
                @keyframes ripple {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    // 7. EFECTO DE CARGA SKELETON
    function initSkeletonLoading() {
        // Esta función simula carga de datos
        const productGrid = document.getElementById('productos-container');
        
        if (productGrid && productGrid.children.length === 0) {
            // Mostrar skeletons mientras cargan los productos
            for (let i = 0; i < 6; i++) {
                const skeletonCard = document.createElement('div');
                skeletonCard.className = 'producto-card skeleton-card';
                skeletonCard.innerHTML = `
                    <div class="skeleton skeleton-img"></div>
                    <div class="producto-info">
                        <div class="skeleton skeleton-text skeleton-text-short"></div>
                        <div class="skeleton skeleton-text"></div>
                        <div class="skeleton skeleton-text" style="width: 40%;"></div>
                        <div class="skeleton skeleton-text"></div>
                    </div>
                `;
                productGrid.appendChild(skeletonCard);
            }
            
            // Simular carga después de 1.5 segundos
            setTimeout(() => {
                // Los productos reales se cargarán aquí
                // Por ahora, removemos los skeletons
                while (productGrid.firstChild) {
                    productGrid.removeChild(productGrid.firstChild);
                }
                // Luego cargaríamos los productos reales
                cargarProductos();
            }, 1500);
        }
    }
    
    // 8. EFECTO DE SCROLL SUAVE MEJORADO
    function initEnhancedSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                if (href === '#' || href === '#!') return;
                
                e.preventDefault();
                
                const targetElement = document.querySelector(href);
                if (!targetElement) return;
                
                // Calcular posición destino
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                const startPosition = window.pageYOffset;
                const distance = targetPosition - startPosition - 80;
                const duration = 1000;
                let start = null;
                
                // Función de easing (suavizado)
                function easeInOutCubic(t) {
                    return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
                }
                
                // Animación
                function animation(currentTime) {
                    if (start === null) start = currentTime;
                    const timeElapsed = currentTime - start;
                    const run = easeInOutCubic(timeElapsed / duration);
                    window.scrollTo(0, startPosition + distance * run);
                    
                    if (timeElapsed < duration) {
                        requestAnimationFrame(animation);
                    }
                }
                
                requestAnimationFrame(animation);
            });
        });
    }
    
    // 9. EFECTO DE HOVER EN ENLACES DEL MENÚ
    function initMenuHoverEffects() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('mouseenter', function() {
                // Efecto de subrayado animado
                const underline = document.createElement('div');
                underline.className = 'link-underline';
                underline.style.cssText = `
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 100%;
                    height: 2px;
                    background-color: var(--secondary-color);
                    transform: scaleX(0);
                    transform-origin: left;
                    transition: transform 0.3s ease;
                `;
                
                this.style.position = 'relative';
                this.appendChild(underline);
                
                // Animar subrayado
                setTimeout(() => {
                    underline.style.transform = 'scaleX(1)';
                }, 10);
            });
            
            link.addEventListener('mouseleave', function() {
                const underline = this.querySelector('.link-underline');
                if (underline) {
                    underline.style.transform = 'scaleX(0)';
                    setTimeout(() => {
                        if (underline.parentNode) {
                            underline.parentNode.removeChild(underline);
                        }
                    }, 300);
                }
            });
        });
    }
    
    // 10. EFECTO DE PARALLAX EN HERO
    function initParallaxEffect() {
        const heroSection = document.querySelector('.hero');
        
        if (!heroSection) return;
        
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            heroSection.style.backgroundPosition = `center ${rate}px`;
        });
    }
    
    // 11. ANIMACIÓN DE TEXTO TIPOWRITER PARA HERO
    function initTypewriterEffect() {
        const heroTitle = document.querySelector('.hero-content h1');
        
        if (!heroTitle) return;
        
        const originalText = heroTitle.textContent;
        heroTitle.textContent = '';
        heroTitle.style.borderRight = '2px solid white';
        
        let i = 0;
        function typeWriter() {
            if (i < originalText.length) {
                heroTitle.textContent += originalText.charAt(i);
                i++;
                setTimeout(typeWriter, 50);
            } else {
                heroTitle.style.borderRight = 'none';
            }
        }
        
        // Iniciar después de un pequeño retraso
        setTimeout(typeWriter, 500);
    }
    
    // 12. EFECTO DE CONTADOR ANIMADO (para estadísticas)
    function initAnimatedCounters() {
        const counters = document.querySelectorAll('.counter');
        
        if (!counters.length) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const counter = entry.target;
                    const target = parseInt(counter.getAttribute('data-target'));
                    const duration = 2000; // 2 segundos
                    const step = target / (duration / 16); // 60fps
                    let current = 0;
                    
                    const updateCounter = () => {
                        current += step;
                        if (current < target) {
                            counter.textContent = Math.ceil(current);
                            requestAnimationFrame(updateCounter);
                        } else {
                            counter.textContent = target;
                        }
                    };
                    
                    updateCounter();
                    observer.unobserve(counter);
                }
            });
        }, { threshold: 0.5 });
        
        counters.forEach(counter => {
            observer.observe(counter);
        });
    }
    
    // INICIALIZAR TODAS LAS ANIMACIONES
    function initAllAnimations() {
        initScrollAnimations();
        initAddToCartAnimations();
        initProductCardHoverEffects();
        initSpecialButtons();
        initSkeletonLoading();
        initEnhancedSmoothScroll();
        initMenuHoverEffects();
        initParallaxEffect();
        initAnimatedCounters();
        
        // Opcional: efecto typewriter (descomentar si quieres usarlo)
        // initTypewriterEffect();
    }
    
    // Ejecutar cuando el DOM esté completamente cargado
    initAllAnimations();
    
    // Re-inicializar animaciones cuando se carguen productos dinámicamente
    window.addEventListener('productsLoaded', function() {
        initAddToCartAnimations();
        initProductCardHoverEffects();
    });
});