document.addEventListener('DOMContentLoaded', function() {
    // Elementos del formulario de login
    const loginForm = document.getElementById('login-form');
    const registerLink = document.getElementById('register-link');
    const registerModal = document.getElementById('register-modal');
    const closeModalButtons = document.querySelectorAll('.close-modal');
    const loginMessage = document.getElementById('login-message');
    
    // Credenciales de administrador (en un sistema real, esto estaría en el servidor)
    const ADMIN_CREDENTIALS = {
        username: 'admin',
        password: 'admin123'
    };
    
    // Manejar envío del formulario de login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const remember = document.querySelector('input[name="remember"]').checked;
            
            // Validar credenciales
            if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
                // Credenciales correctas
                mostrarMensaje('¡Acceso concedido! Redirigiendo al panel de administración...', 'success');
                
                // Guardar sesión si se seleccionó "Recordar"
                if (remember) {
                    localStorage.setItem('adminLoggedIn', 'true');
                } else {
                    sessionStorage.setItem('adminLoggedIn', 'true');
                }
                
                // Redirigir al panel de admin (simulado)
                setTimeout(() => {
                    // En una implementación real, redirigirías a admin.html o admin/
                    window.location.href = 'admin-panel.html';
                }, 1500);
            } else {
                // Credenciales incorrectas
                mostrarMensaje('Usuario o contraseña incorrectos. Intenta con "admin" / "admin123"', 'error');
            }
        });
    }
    
    // Mostrar modal de registro
    if (registerLink) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            registerModal.classList.remove('hidden');
        });
    }
    
    // Cerrar modal de registro
    closeModalButtons.forEach(button => {
        button.addEventListener('click', function() {
            registerModal.classList.add('hidden');
        });
    });
    
    // Cerrar modal haciendo clic fuera
    registerModal.addEventListener('click', function(e) {
        if (e.target === registerModal) {
            registerModal.classList.add('hidden');
        }
    });
    
    // Función para mostrar mensajes
    function mostrarMensaje(texto, tipo) {
        if (!loginMessage) return;
        
        loginMessage.textContent = texto;
        loginMessage.className = `message ${tipo}`;
        loginMessage.classList.remove('hidden');
        
        // Ocultar mensaje después de 5 segundos
        setTimeout(() => {
            loginMessage.classList.add('hidden');
        }, 5000);
    }
    
    // Verificar si ya hay una sesión activa
    if (localStorage.getItem('adminLoggedIn') === 'true' || sessionStorage.getItem('adminLoggedIn') === 'true') {
        // Redirigir automáticamente al panel de admin
        // window.location.href = 'admin-panel.html';
    }
});