// SISTEMA DE CARRITO CON ANIMACIONES

class ShoppingCart {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('shoppingCart')) || [];
        this.cartCount = document.getElementById('cartCount');
        this.cartFloatBtn = document.getElementById('cartFloatBtn');
        this.cartModal = null;
        this.init();
    }
    
    init() {
        this.updateCartUI();
        this.bindEvents();
        this.createCartModal();
    }
    
    bindEvents() {
        // Botón flotante del carrito
        if (this.cartFloatBtn) {
            this.cartFloatBtn.addEventListener('click', () => this.toggleCartModal());
        }
        
        // Evento para agregar productos
        document.addEventListener('addToCart', (e) => {
            this.addItem(e.detail);
        });
    }
    
    createCartModal() {
        // Crear modal del carrito
        this.cartModal = document.createElement('div');
        this.cartModal.className = 'cart-modal';
        this.cartModal.innerHTML = `
            <div class="cart-modal-overlay"></div>
            <div class="cart-modal-content">
                <div class="cart-modal-header">
                    <h3><i class="fas fa-shopping-bag"></i> Tu Carrito</h3>
                    <button class="close-cart">&times;</button>
                </div>
                <div class="cart-modal-body">
                    <div class="cart-items" id="cartItemsContainer">
                        <!-- Items del carrito se cargarán aquí -->
                    </div>
                    <div class="cart-empty" id="cartEmpty">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Tu carrito está vacío</p>
                        <a href="#productos" class="btn-primary">Ver Productos</a>
                    </div>
                    <div class="cart-summary" id="cartSummary">
                        <div class="cart-total">
                            <span>Total:</span>
                            <span class="total-price">$0.00</span>
                        </div>
                        <button class="btn-primary btn-checkout">Proceder al Pago</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(this.cartModal);
        
        // Eventos del modal
        this.cartModal.querySelector('.cart-modal-overlay').addEventListener('click', () => this.hideCartModal());
        this.cartModal.querySelector('.close-cart').addEventListener('click', () => this.hideCartModal());
        this.cartModal.querySelector('.btn-checkout').addEventListener('click', () => this.checkout());
        
        // Estilos dinámicos
        const style = document.createElement('style');
        style.textContent = `
            .cart-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 9999;
            }
            
            .cart-modal.show {
                display: block;
            }
            
            .cart-modal-overlay {
                position: absolute;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(5px);
            }
            
            .cart-modal-content {
                position: absolute;
                top: 0;
                right: 0;
                width: 100%;
                max-width: 400px;
                height: 100%;
                background: white;
                box-shadow: -5px 0 25px rgba(0, 0, 0, 0.2);
                transform: translateX(100%);
                transition: transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                display: flex;
                flex-direction: column;
            }
            
            .cart-modal.show .cart-modal-content {
                transform: translateX(0);
            }
            
            .cart-modal-header {
                padding: 20px;
                background: var(--primary-color);
                color: white;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .cart-modal-header h3 {
                margin: 0;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .close-cart {
                background: none;
                border: none;
                color: white;
                font-size: 1.8rem;
                cursor: pointer;
                line-height: 1;
            }
            
            .cart-modal-body {
                flex: 1;
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }
            
            .cart-items {
                flex: 1;
                overflow-y: auto;
                padding: 20px;
            }
            
            .cart-item {
                display: flex;
                gap: 15px;
                padding: 15px;
                border-bottom: 1px solid #eee;
                animation: slideInRight 0.3s ease;
            }
            
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(30px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            .cart-item-img {
                width: 80px;
                height: 80px;
                border-radius: 8px;
                overflow: hidden;
            }
            
            .cart-item-img img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            
            .cart-item-info {
                flex: 1;
            }
            
            .cart-item-name {
                font-weight: 600;
                margin-bottom: 5px;
            }
            
            .cart-item-price {
                color: var(--secondary-color);
                font-weight: 700;
                margin-bottom: 10px;
            }
            
            .cart-item-actions {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .quantity-control {
                display: flex;
                align-items: center;
                gap: 5px;
            }
            
            .quantity-btn {
                width: 30px;
                height: 30px;
                border-radius: 50%;
                border: 1px solid #ddd;
                background: white;
                cursor: pointer;
                transition: all 0.2s;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .quantity-btn:hover {
                background: var(--primary-color);
                color: white;
                border-color: var(--primary-color);
            }
            
            .quantity {
                width: 40px;
                text-align: center;
                font-weight: 600;
            }
            
            .remove-item {
                background: none;
                border: none;
                color: #e74c3c;
                cursor: pointer;
                font-size: 1.2rem;
                transition: transform 0.2s;
            }
            
            .remove-item:hover {
                transform: scale(1.2);
            }
            
            .cart-empty {
                flex: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 40px;
                text-align: center;
                display: none;
            }
            
            .cart-empty i {
                font-size: 4rem;
                color: #ddd;
                margin-bottom: 20px;
            }
            
            .cart-empty p {
                color: #7f8c8d;
                margin-bottom: 20px;
            }
            
            .cart-summary {
                padding: 20px;
                border-top: 2px solid #eee;
                background: #f9f9f9;
            }
            
            .cart-total {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 1.2rem;
                font-weight: 700;
                margin-bottom: 20px;
            }
            
            .total-price {
                color: var(--secondary-color);
                font-size: 1.4rem;
            }
            
            .btn-checkout {
                width: 100%;
                padding: 15px;
                font-size: 1.1rem;
            }
        `;
        document.head.appendChild(style);
    }
    
    addItem(product) {
        // Verificar si el producto ya está en el carrito
        const existingItem = this.cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            product.quantity = 1;
            this.cart.push(product);
        }
        
        this.saveCart();
        this.updateCartUI();
        this.showAddedAnimation(product);
    }
    
    removeItem(id) {
        this.cart = this.cart.filter(item => item.id !== id);
        this.saveCart();
        this.updateCartUI();
    }
    
    updateQuantity(id, change) {
        const item = this.cart.find(item => item.id === id);
        if (item) {
            item.quantity += change;
            if (item.quantity <= 0) {
                this.removeItem(id);
            } else {
                this.saveCart();
                this.updateCartUI();
            }
        }
    }
    
    saveCart() {
        localStorage.setItem('shoppingCart', JSON.stringify(this.cart));
    }
    
    updateCartUI() {
        // Actualizar contador
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        
        if (this.cartCount) {
            this.cartCount.textContent = totalItems;
            this.cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
            
            // Animación del contador
            if (totalItems > 0) {
                this.cartCount.style.animation = 'bounce 0.5s ease';
                setTimeout(() => {
                    this.cartCount.style.animation = '';
                }, 500);
            }
        }
        
        // Actualizar modal si está abierto
        this.updateCartModal();
    }
    
    updateCartModal() {
        if (!this.cartModal) return;
        
        const itemsContainer = this.cartModal.querySelector('#cartItemsContainer');
        const emptyCart = this.cartModal.querySelector('#cartEmpty');
        const cartSummary = this.cartModal.querySelector('#cartSummary');
        const totalPrice = this.cartModal.querySelector('.total-price');
        
        if (this.cart.length === 0) {
            emptyCart.style.display = 'flex';
            cartSummary.style.display = 'none';
            itemsContainer.innerHTML = '';
        } else {
            emptyCart.style.display = 'none';
            cartSummary.style.display = 'block';
            
            // Calcular total
            const total = this.cart.reduce((sum, item) => {
                return sum + (item.precio * item.quantity);
            }, 0);
            
            totalPrice.textContent = `$${total.toFixed(2)}`;
            
            // Renderizar items
            itemsContainer.innerHTML = this.cart.map(item => `
                <div class="cart-item" data-id="${item.id}">
                    <div class="cart-item-img">
                        <img src="${item.imagen}" alt="${item.nombre}" onerror="this.src='images/placeholder.jpg'">
                    </div>
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.nombre}</div>
                        <div class="cart-item-price">$${item.precio.toFixed(2)}</div>
                        <div class="cart-item-actions">
                            <div class="quantity-control">
                                <button class="quantity-btn minus" data-id="${item.id}">-</button>
                                <span class="quantity">${item.quantity}</span>
                                <button class="quantity-btn plus" data-id="${item.id}">+</button>
                            </div>
                            <button class="remove-item" data-id="${item.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
            
            // Agregar eventos a los botones
            itemsContainer.querySelectorAll('.minus').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = parseInt(e.target.getAttribute('data-id'));
                    this.updateQuantity(id, -1);
                });
            });
            
            itemsContainer.querySelectorAll('.plus').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = parseInt(e.target.getAttribute('data-id'));
                    this.updateQuantity(id, 1);
                });
            });
            
            itemsContainer.querySelectorAll('.remove-item').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = parseInt(e.target.closest('.remove-item').getAttribute('data-id'));
                    this.removeItem(id);
                });
            });
        }
    }
    
    showAddedAnimation(product) {
        // Crear notificación flotante
        const notification = document.createElement('div');
        notification.className = 'item-added-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <img src="${product.imagen}" alt="${product.nombre}">
                <div>
                    <div class="notification-text">¡Agregado al carrito!</div>
                    <div class="notification-product">${product.nombre}</div>
                </div>
            </div>
        `;
        
        // Estilos
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            z-index: 10000;
            transform: translateX(120%);
            transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            max-width: 300px;
        `;
        
        document.body.appendChild(notification);
        
        // Mostrar con animación
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 10);
        
        // Ocultar después de 3 segundos
        setTimeout(() => {
            notification.style.transform = 'translateX(120%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        }, 3000);
    }
    
    toggleCartModal() {
        this.cartModal.classList.toggle('show');
        this.updateCartModal();
        
        // Animación de entrada/salida
        if (this.cartModal.classList.contains('show')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    }
    
    showCartModal() {
        this.cartModal.classList.add('show');
        this.updateCartModal();
        document.body.style.overflow = 'hidden';
    }
    
    hideCartModal() {
        this.cartModal.classList.remove('show');
        document.body.style.overflow = '';
    }
    
    checkout() {
        if (this.cart.length === 0) return;
        
        // Animación de carga
        const checkoutBtn = this.cartModal.querySelector('.btn-checkout');
        const originalText = checkoutBtn.innerHTML;
        checkoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
        checkoutBtn.disabled = true;
        
        // Simular procesamiento de pago
        setTimeout(() => {
            // Mostrar mensaje de éxito
            showNotification('¡Compra realizada con éxito!', 'success');
            
            // Vaciar carrito
            this.cart = [];
            this.saveCart();
            this.updateCartUI();
            
            // Restaurar botón
            checkoutBtn.innerHTML = originalText;
            checkoutBtn.disabled = false;
            
            // Cerrar modal después de un momento
            setTimeout(() => {
                this.hideCartModal();
            }, 1000);
        }, 2000);
    }
    
    getTotalItems() {
        return this.cart.reduce((sum, item) => sum + item.quantity, 0);
    }
    
    getTotalPrice() {
        return this.cart.reduce((sum, item) => sum + (item.precio * item.quantity), 0);
    }
}

// Inicializar carrito cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    window.shoppingCart = new ShoppingCart();
    
    // Modificar la función agregarAlCarrito para usar el nuevo sistema
    window.agregarAlCarrito = function(productoId) {
        // Obtener información del producto
        const productos = JSON.parse(localStorage.getItem('productosTiendaRopa')) || obtenerProductosPorDefecto();
        const producto = productos.find(p => p.id === productoId);
        
        if (producto) {
            // Disparar evento personalizado
            const event = new CustomEvent('addToCart', {
                detail: producto
            });
            document.dispatchEvent(event);
        }
    };
});